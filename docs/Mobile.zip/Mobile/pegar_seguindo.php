<?php
 
/*
 * Following code will create a new product row
 * All product details are read from HTTP Post Request
 */
 
date_default_timezone_set('America/Sao_Paulo');
 
// array for JSON response
$response = array();

// conecta ao BD
$con = pg_connect(getenv("DATABASE_URL"));

if (isset($_POST['login']) && isset($_POST['auth_token'])) {
	
	$login = trim($_POST['login']);
	$auth_token = trim($_POST['auth_token']);
	
	// Verifica se tem autorizacao
	$query = pg_query($con, "SELECT auth_token FROM usuario WHERE login='$login'");
	if(pg_num_rows($query) > 0){
		$row = pg_fetch_array($query);
		if($auth_token == $row['auth_token']){
			$result = pg_query($con, "SELECT usuario_login_seguindo FROM seguindo WHERE usuario_login='$login'");
			if(pg_num_rows($result) > 0) {
				$response["seguindo"] = array();
				
				while ($row = pg_fetch_array($result)) {
					$usuario = array();
					$usuario["login"] = $row["usuario_login_seguindo"];
					
					$seguindo_usuario = $row["usuario_login_seguindo"];
					$result_user = pg_query($con, "SELECT nome, data_nascimento, cidade, foto FROM usuario WHERE login = '$seguindo_usuario'");
					$row_user = pg_fetch_array($result_user);
					$usuario["nome"] = $row_user["nome"];
					$usuario["cidade"] = $row_user["cidade"];
					$usuario["data_nascimento"] = strtotime($row_user["data_nascimento"]);
					$usuario["foto"] = $row_user["foto"];
					
					array_push($response["seguindo"], $usuario);
					
				}
				$response["status"] = 0;
				$response["message"] = "ok";
				
			}
			else {
				$response["status"] = 3;
				$response["message"] = "nao segue ninguem";
			}
		}
		else {
			$response["status"] = 1;
			$response["message"] = "token de autenticacao nao confere";
		}
	}
	else {
		$response["status"] = 1;
		$response["message"] = "usuario nao existe";
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>