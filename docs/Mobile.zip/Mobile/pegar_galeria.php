<?php 
 
// array for JSON response
$response = array();

// conecta ao BD
$con = pg_connect(getenv("DATABASE_URL"));
 
if (isset($_POST['login']) && isset($_POST['auth_token'])) {
	
	$login = trim($_POST['login']);
	$auth_token = trim($_POST['auth_token']);
	
	// Verifica se tem autorizacao
	$query = pg_query($con, "SELECT auth_token FROM usuario WHERE login='$login'");
	if(pg_num_rows($query) > 0){
		$row = pg_fetch_array($query);
		if($auth_token == $row['auth_token']){
			$result = pg_query($con, "SELECT idpost, imagem FROM post WHERE usuario_login='$login' ORDER BY data_hora DESC");		
			if (pg_num_rows($result) > 0) {
		
				$response["fotos"] = array();

				while ($row = pg_fetch_array($result)) {
					$foto = array();
					$foto["idpost"] = $row["idpost"];
					$foto["imagem"] = $row["imagem"];
			 
					if ($foto["imagem"] != '') {
						array_push($response["fotos"], $foto);
					}
				}
				$response["status"] = 0;
				$response["message"] = "ok";
			}
			else {
				$response["status"] = 3;
				$response["message"] = "sem fotos";
			}
		}
		else {
			$response["status"] = 1;
			$response["message"] = "token de autenticacao nao confere";
		}
	}
	else {
		$response["status"] = 1;
		$response["message"] = "usuario nao existe";
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>