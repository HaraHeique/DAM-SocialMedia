<?php
 
/*
 * Following code will create a new product row
 * All product details are read from HTTP Post Request
 */
 
// array for JSON response
$response = array();

date_default_timezone_set('America/Sao_Paulo');

// conecta ao BD
$con = pg_connect(getenv("DATABASE_URL"));
 
if (isset($_POST['auth_token']) && isset($_POST['login']) && isset($_POST['texto'])) {
	
	$login = trim($_POST['login']);
	$auth_token = trim($_POST['auth_token']);
	$texto = trim($_POST['texto']);
	
	// Verifica se tem autorizacao
	$query = pg_query($con, "SELECT auth_token FROM usuario WHERE login='$login'");
	if(pg_num_rows($query) > 0){
		$row = pg_fetch_array($query);
		if($auth_token == $row['auth_token']){
			$date = date('Y-m-d H:i:s');
	
			if (!isset($_FILES['foto'])) {
				if (pg_query($con, "INSERT INTO post(usuario_login, data_hora, texto, imagem) VALUES('$login', '$date', '$texto', '')")) {
					$response["status"] = 0;
					$response["message"] = "ok";
				}
				else {
					$response["status"] = 3;
					$response["message"] = "Error BD: " . pg_last_error($con);
				}
			}
			else {
				$imageFileType = strtolower(pathinfo(basename($_FILES["foto"]["name"]),PATHINFO_EXTENSION));
				$image_base64 = base64_encode(file_get_contents($_FILES['foto']['tmp_name']) );
				$img = 'data:image/'.$imageFileType.';base64,'.$image_base64;
				if (pg_query($con, "INSERT INTO post(usuario_login, data_hora, texto, imagem) VALUES('$login', '$date', '$texto', '$img')")) {
					$response["status"] = 0;
					$response["message"] = "ok";
				}
				else {
					$response["status"] = 3;
					$response["message"] = "Error BD: " . pg_last_error($con);
				}
			}
		}
		else {
			$response["status"] = 1;
			$response["message"] = "token de autenticacao nao confere";
		}
	}
	else {
		$response["status"] = 1;
		$response["message"] = "usuario nao existe";
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>