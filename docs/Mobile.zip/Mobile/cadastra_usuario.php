<?php
 
/*
 * Following code will create a new product row
 * All product details are read from HTTP Post Request
 */
 
function getRandomString($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $string = '';
    for ($i = 0; $i < $length; $i++) {
        $string .= $characters[mt_rand(0, strlen($characters) - 1)];
    }
    return $string;
}
 
// connecting to db
$con = pg_connect(getenv("DATABASE_URL"));
 
// array for JSON response
$response = array();

date_default_timezone_set('America/Sao_Paulo');
 
// check for required fields
if (isset($_POST['login']) && isset($_POST['senha']) && isset($_POST['nome']) && isset($_POST['cidade']) && isset($_POST['data_nascimento']) && isset($_FILES['foto'])) {
 
	$imageFileType = strtolower(pathinfo(basename($_FILES["foto"]["name"]),PATHINFO_EXTENSION));
	$image_base64 = base64_encode(file_get_contents($_FILES['foto']['tmp_name']) );
	$img = 'data:image/'.$imageFileType.';base64,'.$image_base64;
	
	$login = trim($_POST['login']);
	$senha = trim($_POST['senha']);
	$nome = $_POST['nome'];
	$cidade = $_POST['cidade'];
	$data_nascimento = date("Y-m-d", ((int)$_POST['data_nascimento'])/1000);
		
	// mysql inserting a new row
	$usuario_existe = pg_query($con, "SELECT login FROM usuario WHERE login='$login'");
	// check for empty result
	if (pg_num_rows($usuario_existe) > 0) {
		$response["status"] = 3;
		$response["message"] = "usuario ja existe";
	}
	else {
		$auth_token = getRandomString(10);
		// mysql inserting a new row
		$result = pg_query($con, "INSERT INTO usuario(login, senha, auth_token, nome, data_nascimento, cidade, foto, app_token) VALUES('$login', '$senha', '$auth_token', '$nome', '$data_nascimento', '$cidade', '$filename', '')");
 
		//echo("Error description: " . pg_error($con));
		// check if row inserted or not
		if ($result) {
			$response["status"] = 0;
			$response["message"] = "usuario cadastrado com sucesso";
		}
		else {
			$response["status"] = 3;
			$response["message"] = "Error BD: " . pg_last_error($con);
		}
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}

pg_close($con);
echo json_encode($response);
?>