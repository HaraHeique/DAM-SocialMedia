<?php

// connecting to db
$con = pg_connect(getenv("DATABASE_URL"));

// array for JSON response
$response = array();

// check for required fields
if (isset($_POST['login']) && isset($_POST['senha']) && isset($_POST['app_token'])) {
	
    $login = trim($_POST['login']);
	$senha = trim($_POST['senha']);
    $app_token = trim($_POST['app_token']);
	
	$query = pg_query($con, "SELECT senha, auth_token FROM usuario WHERE login='$login'");

	if(pg_num_rows($query) > 0){
		$row = pg_fetch_array($query);
		if($senha == $row['senha']){
			pg_query($con, "UPDATE usuario SET app_token='$app_token' WHERE login='$login'");
			$response["status"] = 0;
			$response["auth_token"] = $row['auth_token'];
			$response["message"] = "usuario logado";
		}
		else {
			// senha ou usuario nao confere
			$response["status"] = 1;
			$response["message"] = "usuario ou senha não confere";
		}
	}
	else {
		// senha ou usuario nao confere
		$response["status"] = 1;
		$response["message"] = "usuario ou senha não confere";
	}
}
else {
	$response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>