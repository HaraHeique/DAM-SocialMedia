<?php
 
date_default_timezone_set('America/Sao_Paulo');

// array for JSON response
$response = array();

// conecta ao BD
$con = pg_connect(getenv("DATABASE_URL"));
 
if (isset($_GET['idpost'])) {
	
	$idpost = trim($_GET['idpost']);

	$result = pg_query($con, "SELECT * FROM post WHERE idpost='$idpost'");
	if (pg_num_rows($result) > 0) {
		
		$response["post"] = array();
		
		$row = pg_fetch_array($result);
		$post = array();
		$post["idpost"] = $row["idpost"];
		
		$post_user = $row["usuario_login"];
		$result_user = pg_query($con, "SELECT nome, foto FROM usuario WHERE login = '$post_user'");
		$row_user = pg_fetch_array($result_user);
		$post["nome"] = $row_user["nome"];
		$post["foto_usuario"] = $row_user["foto"];
		$post["data_hora"] = strtotime($row["data_hora"]);
		$post["texto"] = $row["texto"];
		$post["imagem"] = $row["imagem"];
			
		if (isset($_GET['login'])) {
			$login = trim($_GET['login']);
			$idseguindo = $login . $post_user;
		
			$result_seguindo = pg_query($con, "SELECT idseguindo FROM seguindo WHERE idseguindo='$idseguindo'");
			if(pg_num_rows($result_seguindo) > 0) {
				$post["seguindo"] = 1;
			}
			else {
				$post["seguindo"] = 0;
			}
		}
		else {
			$post["seguindo"] = 0;
		}
	 
		array_push($response["post"], $post);
		
		$response["status"] = 0;
		$response["message"] = "ok";
	}
	else {
		$response["status"] = 3;
		$response["message"] = "post inexistente";
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>