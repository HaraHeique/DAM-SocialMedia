<?php
 
date_default_timezone_set('America/Sao_Paulo');

// array for JSON response
$response = array();

// conecta ao BD
$con = pg_connect(getenv("DATABASE_URL"));
 
if (isset($_GET['idpost'])) {
	
	$idpost = trim($_GET['idpost']);
	
	$result = pg_query($con, "SELECT * FROM comentario WHERE post_idpost='$idpost' ORDER BY data_hora ASC");
	if (pg_num_rows($result) > 0) {
		
		$response["comentarios"] = array();
		
		while ($row = pg_fetch_array($result)) {
			$comentario = array();
			$comentario["idcomentario"] = $row["idcomentario"];
			
			$comentario_usuario = $row["usuario_login"];
			$result_user = pg_query($con, "SELECT nome, foto FROM usuario WHERE login = '$comentario_usuario'");
			$row_user = pg_fetch_array($result_user);
			$comentario["nome"] = $row_user["nome"];
			$comentario["foto_usuario"] = $row_user["foto"];
			$comentario["data_hora"] = strtotime($row["data_hora"]);
			$comentario["texto"] = $row["texto"];
			
			// push single product into final response array
			array_push($response["comentarios"], $comentario);
		}
		
		$response["status"] = 0;
		$response["message"] = "ok";
	}
	else {
		$response["status"] = 3;
		$response["message"] = "sem comentarios";
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>