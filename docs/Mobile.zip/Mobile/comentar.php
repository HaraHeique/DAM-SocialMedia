<?php
 
/*
 * Following code will create a new product row
 * All product details are read from HTTP Post Request
 */
 
date_default_timezone_set('America/Sao_Paulo');

 
define('API_ACCESS_KEY','AAAA6G6a7uk:APA91bG5j6wJVsNwHIjyTy32i6TSmssZAG8T5R55YHIU5KRa2ySoiho55E2w1NylYlE-HzPv6qTMNQdmED1X3ueFW8AeYAEmg5ww-OychOY10SmBSngJutXs_nQmB0PkKB5BCKPTacG3');

// conecta ao BD
$con = pg_connect(getenv("DATABASE_URL"));

// array for JSON response
$response = array();
 
if (isset($_POST['auth_token']) && isset($_POST['login']) && isset($_POST['idpost']) && isset($_POST['comentario'])) {
	
	$login = trim($_POST['login']);
	$auth_token = trim($_POST['auth_token']);
	$idpost = trim($_POST['idpost']);
	$comentario = $_POST['comentario'];
	$date = date('Y-m-d H:i:s');
	
	// Verifica se tem autorizacao
	$query = pg_query($con, "SELECT auth_token FROM usuario WHERE login='$login'");
	if(pg_num_rows($query) > 0){
		$row = pg_fetch_array($query);
		if($auth_token == $row['auth_token']){
			if (pg_query($con, "INSERT INTO comentario(post_idpost, usuario_login, texto, data_hora) VALUES('$idpost', '$login', '$comentario', '$date')")) {
		
				$query = pg_query($con, "SELECT usuario_login FROM post WHERE idpost='$idpost'");
				$row = pg_fetch_array($query);
				$dono_post = $row['usuario_login'];
				
				$query = pg_query($con, "SELECT app_token FROM usuario WHERE login='$dono_post'");
				$row = pg_fetch_array($query);
				$app_token = $row['app_token'];
				
				$query = pg_query($con, "SELECT nome FROM usuario WHERE login='$login'");
				$row = pg_fetch_array($query);
				$dono_comentario = $row['nome'];
				
				$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
				
				$notification = array();
				$notification['idpost'] = $idpost;
				$notification['nome'] = $dono_comentario;

				$fcmNotification = [
					//'registration_ids' => $tokenList, //multple token array
					'to'        => $app_token, //single token
					'data' => $notification
				];

				$headers = [
					'Authorization: key=' . API_ACCESS_KEY,
					'Content-Type: application/json'
				];

				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL,$fcmUrl);
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmNotification));
				$result = curl_exec($ch);
				curl_close($ch);
				
				$response["status"] = 0;
				$response["message"] = "ok";
			}
			else {
				$response["status"] = 3;
				$response["message"] = "Error BD: " . pg_last_error($con);
			}
		}
		else {
			$response["status"] = 1;
			$response["message"] = "token de autenticacao nao confere";
		}
	}
	else {
		$response["status"] = 1;
		$response["message"] = "usuario nao existe";
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>