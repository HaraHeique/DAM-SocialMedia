<?php
 
/*
 * Following code will create a new product row
 * All product details are read from HTTP Post Request
 */
 
date_default_timezone_set('America/Sao_Paulo');

// conecta ao BD
$con = pg_connect(getenv("DATABASE_URL"));
 
// array for JSON response
$response = array();
 
if (isset($_GET['busca'])) {
	
	$busca = trim($_GET['busca'],"\n\r\0\x0B\t");
	
	$result = pg_query($con, "SELECT login, nome, data_nascimento, cidade, foto FROM usuario WHERE nome LIKE '%$busca%'");
	if(pg_num_rows($result) > 0) {
		$response["usuarios"] = array();
		
		while ($row = pg_fetch_array($result)) {
			$usuario = array();
			$usuario["login"] = $row["login"];
			$usuario["nome"] = $row["nome"];
			$usuario["cidade"] = $row["cidade"];
			$usuario["data_nascimento"] = new DateTime($row["data_nascimento"]);
			$usuario["foto"] = $row["foto"];
			
			if (isset($_GET['login'])) {
				$login = $_GET['login'];
				$idseguindo = $login . $row["login"];
			
				$result_seguindo = pg_query($con, "SELECT idseguindo FROM seguindo WHERE idseguindo='$idseguindo'");
				if(pg_num_rows($result_seguindo) > 0) {
					$usuario["seguindo"] = 1;
				}
				else {
					$usuario["seguindo"] = 0;
				}
			}
			else {
				$usuario["seguindo"] = 0;
			}
			
			array_push($response["usuarios"], $usuario);
			
		}
		$response["status"] = 0;
		$response["message"] = "ok";
	}
	else {
		$response["status"] = 3;
		$response["message"] = "nenhum usuario encontrado";
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>