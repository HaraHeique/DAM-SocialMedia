<?php
 
date_default_timezone_set('America/Sao_Paulo');

 
function date_compare($a, $b) {
	$t1 = strtotime($a['data_hora']);
	$t2 = strtotime($b['data_hora']);
	return $t1 - $t2;
}  
 
// array for JSON response
$response = array();

// conecta ao BD
$con = pg_connect(getenv("DATABASE_URL"));

if (isset($_POST['tipo_timeline'])) {
	
	$tipo_timeline = trim($_POST['tipo_timeline']);
	
	if ($tipo_timeline == '0') {

		$result = pg_query($con, "SELECT * FROM post");
		
		if (pg_num_rows($result) > 0) {
			
			$response["posts"] = array();
		 
			while ($row = pg_fetch_array($result)) {
				$post = array();
				$post["idpost"] = $row["idpost"];
				
				$post_user = $row["usuario_login"];
				$result_user = pg_query($con, "SELECT nome, foto FROM usuario WHERE login = '$post_user'");
				$row_user = pg_fetch_array($result_user);
				$post["login"] = $row["usuario_login"];
				$post["nome"] = $row_user["nome"];
				$post["foto_usuario"] = $row_user["foto"];
				$post["data_hora"] = strtotime($row["data_hora"]);
				$post["texto"] = $row["texto"];
				$post["imagem"] = $row["imagem"];
				
				if (isset($_POST['login'])) {
					$login = trim($_POST['login']);
					$idseguindo = $login . $post_user;
				
					$result_seguindo = pg_query($con, "SELECT idseguindo FROM seguindo WHERE idseguindo='$idseguindo'");
					if(pg_num_rows($result_seguindo) > 0) {
						$post["seguindo"] = 1;
					}
					else {
						$post["seguindo"] = 0;
					}
				}
				else {
					$post["seguindo"] = 0;
				}
		 
				// push single product into final response array
				array_push($response["posts"], $post);
			}
			
			$response["status"] = 0;
			$response["message"] = "ok";
		}
		else {
			$response["status"] = 3;
			$response["message"] = "sem posts";
		}
	}
	else {
		if (isset($_POST['login']) && isset($_POST['auth_token'])) {
			$login = trim($_POST['login']);
			$auth_token = trim($_POST['auth_token']);
			
			// Verifica se tem autorizacao
			$query = pg_query($con, "SELECT auth_token FROM usuario WHERE login='$login'");
			if(pg_num_rows($query) > 0){
				$row = pg_fetch_array($query);
				if($auth_token == $row['auth_token']){
					if ($tipo_timeline == '1') {
						$result_seguindo = pg_query($con, "SELECT usuario_login_seguindo FROM seguindo WHERE usuario_login='$login'");
						if(pg_num_rows($result_seguindo) > 0) {
							while ($row_seguindo = pg_fetch_array($result_seguindo)) {
								
								$usuario_login_seguindo = $row_seguindo["usuario_login_seguindo"];
								$result = pg_query($con, "SELECT * FROM post WHERE usuario_login='$usuario_login_seguindo'");
								
								if (pg_num_rows($result) > 0) {
									
									$response["posts"] = array();
						 
									while ($row = pg_fetch_array($result)) {
										// temp user array
										$post = array();
										$post["idpost"] = $row["idpost"];
										
										$post_user = $row["usuario_login"];
										$result_user = pg_query($con, "SELECT nome, foto FROM usuario WHERE login = '$post_user'");
										$row_user = pg_fetch_array($result_user);
										$post["login"] = $row["usuario_login"];
										$post["nome"] = $row_user["nome"];
										$post["foto_usuario"] = $row_user["foto"];
										$post["data_hora"] = strtotime($row["data_hora"]);
										$post["texto"] = $row["texto"];
										$post["imagem"] = $row["imagem"];
										$post["seguindo"] = 1;
								 
										// push single product into final response array
										array_push($response["posts"], $post);
									}
								}
							}
							
							$response["status"] = 0;
							$response["message"] = "ok";
						}
						else {
							$response["status"] = 3;
							$response["message"] = "sem posts";
						}
					}
					else {
						if ($tipo_timeline == '2') {
		
							$result = pg_query($con, "SELECT * FROM post WHERE usuario_login='$login'");
									
							if (pg_num_rows($result) > 0) {
								
								$response["posts"] = array();
					 
								while ($row = pg_fetch_array($result)) {
									// temp user array
									$post = array();
									$post["idpost"] = $row["idpost"];
									
									$post_user = $row["usuario_login"];
									$result_user = pg_query($con, "SELECT nome, foto FROM usuario WHERE login = '$post_user'");
									$row_user = pg_fetch_array($result_user);
									$post["login"] = $row["usuario_login"];
									$post["nome"] = $row_user["nome"];
									$post["foto_usuario"] = $row_user["foto"];
									$post["data_hora"] = strtotime($row["data_hora"]);
									$post["texto"] = $row["texto"];
									$post["imagem"] = $row["imagem"];
									$post["seguindo"] = 1;
							 
									array_push($response["posts"], $post);
								}
								
								$response["status"] = 0;
								$response["message"] = "ok";
							}
							else {
								$response["status"] = 3;
								$response["message"] = "sem posts";
								
							}
						}
						else {
							$response["status"] = 2;
							$response["message"] = "parametros incorretos";
						}
					}
				}
				else {
					$response["status"] = 1;
					$response["message"] = "token de autenticacao nao confere";
				}
			}
			else {
				$response["status"] = 1;
				$response["message"] = "usuario nao existe";
			}
		}
		else {
			$response["status"] = 2;
			$response["message"] = "sem informacoes de login";
		}
	}
  
	if($response["status"] == 0) {
		usort($response["posts"], 'date_compare');
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>