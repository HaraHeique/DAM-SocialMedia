<?php
 
/*
 * Following code will create a new product row
 * All product details are read from HTTP Post Request
 */
 
// array for JSON response
$response = array();

// conecta ao BD
$con = pg_connect(getenv("DATABASE_URL"));
 
if (isset($_POST['auth_token']) && isset($_POST['login']) && isset($_POST['quem'])) {
	
	$login = trim($_POST['login']);
	$auth_token = trim($_POST['auth_token']);
	$quem = trim($_POST['quem']);
	$id = $login . $quem;
	
	// Verifica se tem autorizacao
	$query = pg_query($con, "SELECT auth_token FROM usuario WHERE login='$login'");
	if(pg_num_rows($query) > 0){
		$row = pg_fetch_array($query);
		if($auth_token == $row['auth_token']){
			$result = pg_query($con, "SELECT idseguindo FROM seguindo WHERE idseguindo='$id'");
			if(pg_num_rows($result) == 0) {
				$response["status"] = 3;
				$response["message"] = "usuario ja nao era seguido";
			}
			else {
				if (pg_query($con, "DELETE FROM seguindo WHERE idseguindo = '$id'")) {
					$response["status"] = 0;
					$response["message"] = "ok";
				}
				else {
					$response["status"] = 3;
					$response["message"] = "Error BD: " . pg_last_error($con);
				}
			}
		}
		else {
			$response["status"] = 1;
			$response["message"] = "token de autenticacao nao confere";
		}
	}
	else {
		$response["status"] = 1;
		$response["message"] = "usuario nao existe";
	}
}
else {
    $response["status"] = 2;
	$response["message"] = "faltam parametros";
}
pg_close($con);
echo json_encode($response);
?>